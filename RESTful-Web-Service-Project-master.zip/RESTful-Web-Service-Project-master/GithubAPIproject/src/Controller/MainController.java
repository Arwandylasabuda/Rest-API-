package Controller;

import View.MainPanel;

/**
 * Created by GL552VW on 6/3/2017.
 */
public class MainController {
    public static void main(String[] args) {
        MainPanel panelUtama = new MainPanel();
        panelUtama.ViewMainPanel();
    }
}
